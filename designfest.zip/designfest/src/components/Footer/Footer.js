import React from 'react';
import './Footer.css';
import FaceBook from '../../images/fbicon.png'
import insta from '../../images/insta.png'
import twitter from '../../images/twitter.png'

const Footer = () => {
  return (
    <footer className="footer">
      <p>Contact us at info@designfest.com</p>
      <div className="social-links">
        <a href="https://facebook.com" aria-label="Facebook">
          <img src={FaceBook} alt="Facebook" className="social-icon" />
        </a>
        <a href="https://twitter.com" aria-label="Twitter">
          <img src={twitter} alt="Twitter" className="social-icon" />
        </a>
        <a href="https://instagram.com" aria-label="Instagram">
          <img src={insta} alt="Instagram" className="social-icon" />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
