import React from 'react';
import './AboutSection.css';

const AboutSection = () => {
    return (
        <div className="about">
            <h2>About us</h2>
            <p>oin us at Design Fest 2024, a premier event celebrating the world of design in all its forms! Whether you’re a seasoned professional, a budding designer, or simply passionate about creativity, this event is the place to be. Immerse yourself in a vibrant environment filled with inspiring talks, hands-on workshops, and networking opportunities with some of the brightest minds in the industry.

                At Design Fest 2024, you’ll explore the latest trends, tools, and techniques shaping the future of design. From graphic design and UI/UX to architecture and industrial design, this event covers it all. Our lineup of expert speakers will share their insights and experiences, giving you a fresh perspective on how to push the boundaries of creativity.

                Don’t miss this opportunity to connect with fellow designers, discover cutting-edge innovations, and ignite your creative spark. Whether you're looking to refine your skills, showcase your work, or get inspired, Design Fest 2024 is your destination.</p>
        </div>
    );
};

export default AboutSection;
