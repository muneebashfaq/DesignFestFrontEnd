import React from 'react';
import './HeroSection.css'; // or use styled-components
import banner from '../../images/HeroSectionBanner.jpg'; 
const HeroSection = () => {
  return (
    <div className="hero">
      <img src={banner} alt="Event Banner" className="hero-image" />
      <div className="hero-content">
        <button className="cta-button">Register Now</button>
      </div>
    </div>
  );
};

export default HeroSection;
