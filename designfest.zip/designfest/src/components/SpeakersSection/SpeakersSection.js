import React from 'react';
import './SpeakerSections.css';
import speaker1 from '../../images/speaker1.jpg'
import speaker2 from '../../images/speaker2.jpg'
import speaker3 from '../../images/speaker3.jpg'
import BasicModal from '../../helpers/modal';

const speakers = [
    { name: 'Emily ', title: 'CEO of DesignWave', img: `${speaker1}`, des: 'Emily, the CEO of DesignWave, leads with a visionary approach that drives innovation and excellence in design. Her leadership has established DesignWave as a trailblazer in creating cutting-edge design solutions' },
    { name: 'Sophia', title: 'CTO of Blueprint Design Co.', img: `${speaker2}`, des: 'Sophia, the CTO of Blueprint Design Co., spearheads technological advancements with a passion for innovation. Her expertise has been pivotal in shaping the companys cutting-edge design solutions and tech-driven strategies.' },
    { name: 'Daniel', title: 'Founder of Visionary Designs Inc.', img: `${speaker3}`, des: 'Daniel, the founder of Visionary Designs Inc., has built a reputation for pioneering design excellence. His creative vision and entrepreneurial spirit have established the company as a leader in transformative design solutions' },
];

const SpeakersSection = () => {
    const [open, setOpen] = React.useState(false);
    const [Descp, setDescp] = React.useState(false);

    const handleClose=()=>{
        setOpen(false)
    }
    const handleOpen=(desc)=>{
        setDescp(desc)
        setOpen(true)
    }
    return (
        <div className="speakers">
            <h2>Our Speakers</h2>
            <BasicModal
                open={open}
                handleClose={handleClose}
                description={Descp}
            />
            <div className="speakers-grid">
                {speakers.map((speaker, index) => (
                    <div className="speaker-card" key={index}>
                        <img src={speaker.img} alt={speaker.name} className="speaker-img" />
                        <h3 onClick={()=>{handleOpen(speaker.des)}} className="speaker-title">{speaker.name}</h3>
                        <p>{speaker.title}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SpeakersSection;
