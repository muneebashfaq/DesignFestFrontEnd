import logo from './logo.svg';
import './App.css';
import HeroSection from './components/HeroSection/HeroSection';
import AboutSection from './components/AboutSection/AboutSection';
import SpeakersSection from './components/SpeakersSection/SpeakersSection';
import Footer from './components/Footer/Footer';
function App() {
  return (<>
  <HeroSection/>
  <AboutSection/>
  <SpeakersSection/>
  <Footer/>
  </>
   
   
  );
}

export default App;
